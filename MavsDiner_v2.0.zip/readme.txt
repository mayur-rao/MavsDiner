MavsDiner Android Project Code
Version: 2.0
Project Group#: Team  6
Section: 2162-CSE-5324-003-SFWR-ENG-I-ANLY-DSGN-TESTING--2016-Spring

Team Members:
Chetan There
Jubin Sanghvi
Mark Ashley Fernandes 
Mayur Mukund Rao
Swaroop Raja Srinivas Setty
Vyshak Mulbagal Bheema Rao

Description:
MavsDiner is an all-in-one app that lets users to view all the restaurant menus.
Provides an interface to add food items to cart from multiple vendors, under one order.
Get notified when the order is ready.
Rate, view restaurants on a map.
Vendor can modify the restaurant menu, view all the orders from its customers
Vendor notifies customer once the item is ready for take-out. Change restaurant availability.

Build Date: 05/03/2015

Login Credentials:
customer-
username: swa@gmail.com
password: 456  or 123

vendor-
username: texadelphia@aramark.com
password: 123

username: moes@aramark.com
password: 456 or 123

username: piefive@aramark.com
password: 123

Project Folder contains: android code, php files and .sql backup file