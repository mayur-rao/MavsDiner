<?php

define('hostname','omega.uta.edu');
define('user','sxr5833');
define('password','Ab112233');
define('databaseName','sxr5833');

$connect= mysqli_connect(hostname,user,password,databaseName);
//$connect= mysql_connect(hostname,user,password,databaseName,$port,$socket);

?>