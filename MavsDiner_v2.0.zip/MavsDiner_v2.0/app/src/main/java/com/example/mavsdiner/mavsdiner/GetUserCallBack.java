package com.example.mavsdiner.mavsdiner;

/**
 * Created by Swaroop on 4/9/16.
 */
public interface GetUserCallBack {
    public abstract void done(User returnedUser);
}
