package com.example.mavsdiner.mavsdiner;

import android.widget.EditText;

/**
 * Created by Swaroop on 4/26/16.
 */
public interface CustomButtonListener {
    public abstract void onButtonClickListener(int position, EditText editText, int value);
}
