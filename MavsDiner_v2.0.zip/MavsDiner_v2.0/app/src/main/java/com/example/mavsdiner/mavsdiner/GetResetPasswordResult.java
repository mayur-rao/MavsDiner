package com.example.mavsdiner.mavsdiner;

/**
 * Created by Swaroop on 4/14/16.
 */
public interface GetResetPasswordResult {
    public abstract void done(String result);
}
