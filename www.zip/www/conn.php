<?php

define('hostname','localhost');
define('user','root');
define('password','');
define('databaseName','mavsdiner');

$connect= mysqli_connect(hostname,user,password,databaseName);
//$connect= mysql_connect(hostname,user,password,databaseName,$port,$socket);

?>